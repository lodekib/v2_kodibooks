<x-filament-panels::page>
    {{$this->record}}
    @livewire('client-invoices')
</x-filament-panels::page>